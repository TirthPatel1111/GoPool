# Welcome to documentation of Leo-Express-Backend

### By Malay Bhavsar

<table>
<tr>
<td colspan='3'>Index</td>
</tr>
<tr>
<th>Sr No</th>
<th>Name</th>
<th>Number of APIs</th>
</tr>
<tr>
<td>1</td>
<td><a href="/Leo-Express-Backend/Auth">Authentication</a></td>
<td>4</td>
</tr>
<tr>
<td>2</td>
<td><a href="/Leo-Express-Backend/Store">Store</a></td>
<td>12</td>
</tr>
<tr>
<td>3</td>
<td><a href="/Leo-Express-Backend/Foodie">Foodie</a></td>
<td>19</td>
</tr>
<tr>
<td>4</td>
<td><a href="/Leo-Express-Backend/Note">Note</a></td>
<td>4</td>
</tr>
<tr>
<td>5</td>
<td><a href="/Leo-Express-Backend/Events">Events</a></td>
<td>9</td>
</tr>
<tr>
<td>6</td>
<td><a href="/Leo-Express-Backend/Blog">Blogs</a></td>
<td>5</td>
</tr>
</table>
