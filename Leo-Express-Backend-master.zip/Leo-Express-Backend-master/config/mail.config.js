module.exports = {
    host: "",
    port: 527,
    senderEmail: "",
    username: "",
    password: "",
};
