module.exports = {
    key: "This_is_sample_jwt_key",
    StoreMerchantKey: "Store_Merchant_Say_Hello",
    expireTime: "1d",
    merchantExpireTime: "15mins",
};
